OC Group Rehab Analyzer - Clean Deploy Version

Files:
- app/page.jsx
- netlify/functions/analyze-photos.js
- package.json
- netlify.toml

Required Netlify environment variable:
- OPENAI_API_KEY

Optional:
- OPENAI_VISION_MODEL=gpt-4.1-mini

How to deploy:
1. Replace your repo with these files
2. Push to GitHub
3. Netlify will redeploy automatically
4. Add OPENAI_API_KEY in Netlify Site Settings > Environment Variables
