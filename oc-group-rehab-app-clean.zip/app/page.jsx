
"use client";

import React, { useMemo, useState } from "react";

const DEFAULTS = {
  laborMarkupPct: 0.1,
  projectManagementPct: 0.3,
  contingencyPct: 0.1,
  sellingCostPct: 0.1,
  holdMonths: 4,
  monthlyHoldCost: 1500,
};

const PRICING = {
  interiorPaintPerSqft: 2.25,
  lvpPerSqft: 4.25,
  kitchenDemoAllowance: 950,
  cabinetPaintAllowance: 1800,
  quartzCounterAllowance: 2600,
  backsplashAllowance: 900,
  sinkFaucetAllowance: 500,
  appliancePackageAllowance: 2500,
  bathroomDemoAllowance: 550,
  tubShowerSurroundAllowance: 2200,
  vanityAllowance: 950,
  toiletAllowance: 325,
  bathLightMirrorAllowance: 275,
  roofReplacementAllowance: 7800,
  hvacReplacementAllowance: 6500,
  waterHeaterAllowance: 1500,
  electricalPanelAllowance: 2500,
  plumbingRepairAllowance: 2200,
  foundationRepairAllowance: 8500,
  exteriorCleanupAllowance: 900,
  exteriorPaintAllowance: 2800,
  windowRepairAllowance: 1200,
  landscapingAllowance: 950,
  porchRepairAllowance: 1100,
};

const ROOM_OPTIONS = [
  ["kitchen", "Kitchen"],
  ["bathroom", "Bathroom"],
  ["bedroom", "Bedroom"],
  ["living", "Living Area"],
  ["exterior", "Exterior"],
  ["systems", "Systems / Major Components"],
];

const CONDITION_MULTIPLIERS = {
  light: 0.75,
  moderate: 1,
  heavy: 1.25,
  severe: 1.6,
};

function currency(n) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(Number(n || 0));
}

function makeTemplate(type, p) {
  const templates = {
    kitchen: [
      { name: "Demo / haul-off", unit: "allowance", qty: 1, cost: p.kitchenDemoAllowance },
      { name: "Cabinet paint / hardware refresh", unit: "allowance", qty: 1, cost: p.cabinetPaintAllowance },
      { name: "Quartz countertops", unit: "allowance", qty: 1, cost: p.quartzCounterAllowance },
      { name: "Backsplash tile", unit: "allowance", qty: 1, cost: p.backsplashAllowance },
      { name: "Sink / faucet replacement", unit: "allowance", qty: 1, cost: p.sinkFaucetAllowance },
      { name: "Appliance package", unit: "allowance", qty: 1, cost: p.appliancePackageAllowance },
      { name: "LVP flooring", unit: "sqft", qty: 150, cost: p.lvpPerSqft },
    ],
    bathroom: [
      { name: "Demo / haul-off", unit: "allowance", qty: 1, cost: p.bathroomDemoAllowance },
      { name: "Tub or shower surround", unit: "allowance", qty: 1, cost: p.tubShowerSurroundAllowance },
      { name: "Vanity + top + faucet", unit: "allowance", qty: 1, cost: p.vanityAllowance },
      { name: "Toilet replace", unit: "allowance", qty: 1, cost: p.toiletAllowance },
      { name: "Mirror + light", unit: "allowance", qty: 1, cost: p.bathLightMirrorAllowance },
    ],
    bedroom: [
      { name: "Interior paint", unit: "sqft", qty: 420, cost: p.interiorPaintPerSqft },
      { name: "LVP flooring", unit: "sqft", qty: 140, cost: p.lvpPerSqft },
    ],
    living: [
      { name: "Interior paint", unit: "sqft", qty: 600, cost: p.interiorPaintPerSqft },
      { name: "LVP flooring", unit: "sqft", qty: 240, cost: p.lvpPerSqft },
    ],
    exterior: [
      { name: "Exterior cleanup / haul-off", unit: "allowance", qty: 1, cost: p.exteriorCleanupAllowance },
      { name: "Paint / siding repairs", unit: "allowance", qty: 1, cost: p.exteriorPaintAllowance },
      { name: "Window repair allowance", unit: "allowance", qty: 1, cost: p.windowRepairAllowance },
      { name: "Landscaping / grading", unit: "allowance", qty: 1, cost: p.landscapingAllowance },
      { name: "Porch / step repairs", unit: "allowance", qty: 1, cost: p.porchRepairAllowance },
    ],
    systems: [
      { name: "Roof replacement allowance", unit: "allowance", qty: 1, cost: p.roofReplacementAllowance },
      { name: "HVAC replacement allowance", unit: "allowance", qty: 1, cost: p.hvacReplacementAllowance },
      { name: "Water heater", unit: "allowance", qty: 1, cost: p.waterHeaterAllowance },
      { name: "Electrical panel upgrade", unit: "allowance", qty: 1, cost: p.electricalPanelAllowance },
      { name: "Plumbing repair allowance", unit: "allowance", qty: 1, cost: p.plumbingRepairAllowance },
      { name: "Foundation repair allowance", unit: "allowance", qty: 1, cost: p.foundationRepairAllowance },
    ],
  };
  return (templates[type] || []).map((item) => ({ id: crypto.randomUUID(), ...item }));
}

function createRoom(type = "kitchen") {
  return {
    id: crypto.randomUUID(),
    name: "",
    type,
    condition: "moderate",
    sqft: "",
    notes: "",
    contractorQuote: "",
    selectedImages: [],
    lineItems: makeTemplate(type, PRICING),
  };
}

async function fileToDataUrl(file) {
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}

async function createPhotoAssets(files) {
  const list = Array.from(files || []);
  return await Promise.all(
    list.map(async (f) => ({
      id: crypto.randomUUID(),
      name: f.name,
      previewUrl: URL.createObjectURL(f),
      mimeType: f.type || "image/jpeg",
      dataUrl: await fileToDataUrl(f),
    }))
  );
}

function field(label, node) {
  return (
    <label style={{ display: "grid", gap: 6 }}>
      <span style={{ fontSize: 12, color: "#475569" }}>{label}</span>
      {node}
    </label>
  );
}

export default function Page() {
  const [property, setProperty] = useState({
    address: "",
    city: "Wichita",
    state: "KS",
    sqft: "",
    yearBuilt: "",
    propertyType: "single_family",
    purchasePrice: "",
    arv: "",
    targetProfit: 25000,
    lenderLtv: 0.7,
    exitStrategy: "flip",
    notes: "",
  });

  const [rooms, setRooms] = useState([createRoom()]);
  const [visionResults, setVisionResults] = useState([]);
  const [visionLoading, setVisionLoading] = useState(false);
  const [visionError, setVisionError] = useState("");

  const budgets = useMemo(() => {
    return rooms.map((room) => {
      const multiplier = CONDITION_MULTIPLIERS[room.condition] || 1;
      const lineItems = room.lineItems.map((item) => {
        let qty = Number(item.qty || 0);
        if (item.unit === "sqft" && room.sqft) qty = Number(room.sqft);
        return { ...item, qty, total: qty * Number(item.cost || 0) * multiplier };
      });
      const aiSubtotal = lineItems.reduce((sum, i) => sum + i.total, 0);
      const contractorQuote = Number(room.contractorQuote || 0);
      const subtotal = contractorQuote > 0 ? contractorQuote : aiSubtotal;
      return { ...room, lineItems, aiSubtotal, subtotal };
    });
  }, [rooms]);

  const totals = useMemo(() => {
    const directCost = budgets.reduce((sum, r) => sum + r.subtotal, 0);
    const laborMarkup = directCost * DEFAULTS.laborMarkupPct;
    const projectManagement = directCost * DEFAULTS.projectManagementPct;
    const contingency = directCost * DEFAULTS.contingencyPct;
    const holdCost = DEFAULTS.holdMonths * DEFAULTS.monthlyHoldCost;
    const rehabTotal = directCost + laborMarkup + projectManagement + contingency;
    const arv = Number(property.arv || 0);
    const purchasePrice = Number(property.purchasePrice || 0);
    const targetProfit = Number(property.targetProfit || 0);
    const sellingCosts = arv * DEFAULTS.sellingCostPct;
    const totalProjectCost = purchasePrice + rehabTotal + holdCost + sellingCosts;
    const projectedProfit = arv - totalProjectCost;
    const mao70 = arv * 0.7 - rehabTotal;
    const maoStrict = arv * Number(property.lenderLtv || 0) - rehabTotal - holdCost - sellingCosts - targetProfit;
    return { directCost, rehabTotal, projectedProfit, mao70, maoStrict };
  }, [budgets, property]);

  function updateRoom(roomId, patch) {
    setRooms((prev) =>
      prev.map((room) => {
        if (room.id !== roomId) return room;
        const next = { ...room, ...patch };
        if (patch.type && patch.type !== room.type) next.lineItems = makeTemplate(patch.type, PRICING);
        return next;
      })
    );
  }

  function updateLineItem(roomId, itemId, patch) {
    setRooms((prev) =>
      prev.map((room) =>
        room.id !== roomId ? room : { ...room, lineItems: room.lineItems.map((i) => (i.id === itemId ? { ...i, ...patch } : i)) }
      )
    );
  }

  function addRoom() {
    setRooms((prev) => [...prev, createRoom()]);
  }

  function removeRoom(roomId) {
    setRooms((prev) => prev.filter((r) => r.id !== roomId));
  }

  async function analyzeAllPhotos() {
    setVisionLoading(true)
    setVisionError("")
    try {
      const payload = {
        property,
        pricingLibrary: PRICING,
        rooms: rooms.map((room) => ({
          id: room.id,
          name: room.name,
          type: room.type,
          condition: room.condition,
          sqft: room.sqft,
          notes: room.notes,
          images: (room.selectedImages || []).map((img) => ({
            name: img.name,
            mimeType: img.mimeType,
            dataUrl: img.dataUrl,
          })),
        })),
      };

      const response = await fetch("/.netlify/functions/analyze-photos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!response.ok) throw new Error("Photo analysis request failed");
      const data = await response.json();
      setVisionResults(Array.isArray(data.results) ? data.results : []);
    } catch (error) {
      setVisionError(error.message || "Analysis failed");
    } finally {
      setVisionLoading(false);
    }
  }

  function applyVisionResult(result) {
    setRooms((prev) =>
      prev.map((room) => {
        if (room.id !== result.roomId) return room;
        const newItems = (result.suggestedScope || []).map((item) => ({ id: crypto.randomUUID(), ...item }));
        return {
          ...room,
          condition: result.condition || room.condition,
          notes: `${room.notes || ""}${room.notes ? "\\n" : ""}AI analysis: ${(result.issues || []).join("; ")}`,
          lineItems: [...room.lineItems, ...newItems],
        };
      })
    );
  }

  return (
    <main style={{ maxWidth: 1200, margin: "0 auto", padding: 24, fontFamily: "Arial, sans-serif", color: "#0f172a" }}>
      <h1 style={{ marginBottom: 6 }}>OC Group Rehab Analyzer</h1>
      <p style={{ marginTop: 0, color: "#475569" }}>Clean Netlify-ready version with real image uploads and AI vision analysis.</p>

      <section style={{ border: "1px solid #e2e8f0", borderRadius: 14, padding: 16, marginBottom: 18 }}>
        <h2 style={{ marginTop: 0 }}>Property Intake</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0,1fr))", gap: 12 }}>
          {field("Address", <input value={property.address} onChange={(e) => setProperty({ ...property, address: e.target.value })} />)}
          {field("City", <input value={property.city} onChange={(e) => setProperty({ ...property, city: e.target.value })} />)}
          {field("Sq Ft", <input value={property.sqft} onChange={(e) => setProperty({ ...property, sqft: e.target.value })} />)}
          {field("Year Built", <input value={property.yearBuilt} onChange={(e) => setProperty({ ...property, yearBuilt: e.target.value })} />)}
          {field("Purchase Price", <input value={property.purchasePrice} onChange={(e) => setProperty({ ...property, purchasePrice: e.target.value })} />)}
          {field("ARV", <input value={property.arv} onChange={(e) => setProperty({ ...property, arv: e.target.value })} />)}
        </div>
      </section>

      <section style={{ border: "1px solid #e2e8f0", borderRadius: 14, padding: 16, marginBottom: 18 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2 style={{ marginTop: 0 }}>Photos & Rooms</h2>
          <button onClick={addRoom}>Add Room</button>
        </div>

        {rooms.map((room, idx) => (
          <div key={room.id} style={{ border: "1px solid #e2e8f0", borderRadius: 12, padding: 12, marginTop: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <strong>Room {idx + 1}</strong>
              {rooms.length > 1 && <button onClick={() => removeRoom(room.id)}>Remove</button>}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0,1fr))", gap: 10 }}>
              {field("Room Name", <input value={room.name} onChange={(e) => updateRoom(room.id, { name: e.target.value })} />)}
              {field("Room Type",
                <select value={room.type} onChange={(e) => updateRoom(room.id, { type: e.target.value })}>
                  {ROOM_OPTIONS.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
                </select>
              )}
              {field("Condition",
                <select value={room.condition} onChange={(e) => updateRoom(room.id, { condition: e.target.value })}>
                  <option value="light">Light</option>
                  <option value="moderate">Moderate</option>
                  <option value="heavy">Heavy</option>
                  <option value="severe">Severe</option>
                </select>
              )}
              {field("Approx Room Sq Ft", <input value={room.sqft} onChange={(e) => updateRoom(room.id, { sqft: e.target.value })} />)}
            </div>

            <div style={{ marginTop: 10 }}>
              {field("Notes / Observations",
                <textarea
                  style={{ width: "100%", minHeight: 80 }}
                  value={room.notes}
                  onChange={(e) => updateRoom(room.id, { notes: e.target.value })}
                />
              )}
            </div>

            <div style={{ marginTop: 10 }}>
              {field("Room Photos",
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={async (e) => {
                    const assets = await createPhotoAssets(e.target.files);
                    updateRoom(room.id, { selectedImages: assets });
                  }}
                />
              )}
            </div>

            {!!room.selectedImages?.length && (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0,1fr))", gap: 8, marginTop: 10 }}>
                {room.selectedImages.map((img) => (
                  <div key={img.id} style={{ border: "1px solid #e2e8f0", borderRadius: 8, padding: 6 }}>
                    <img src={img.previewUrl} alt={img.name} style={{ width: "100%", height: 120, objectFit: "cover", borderRadius: 6 }} />
                    <div style={{ fontSize: 12, marginTop: 6 }}>{img.name}</div>
                  </div>
                ))}
              </div>
            )}

            <div style={{ marginTop: 12, fontWeight: 600 }}>Scope Items</div>
            <div style={{ marginTop: 8 }}>
              {room.lineItems.map((item) => (
                <div key={item.id} style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 8, marginBottom: 8 }}>
                  <input value={item.name} onChange={(e) => updateLineItem(room.id, item.id, { name: e.target.value })} />
                  <select value={item.unit} onChange={(e) => updateLineItem(room.id, item.id, { unit: e.target.value })}>
                    <option value="allowance">allowance</option>
                    <option value="sqft">sqft</option>
                    <option value="lf">lf</option>
                    <option value="ea">ea</option>
                  </select>
                  <input type="number" value={item.qty} onChange={(e) => updateLineItem(room.id, item.id, { qty: e.target.value })} />
                  <input type="number" value={item.cost} onChange={(e) => updateLineItem(room.id, item.id, { cost: e.target.value })} />
                </div>
              ))}
            </div>
          </div>
        ))}

        <div style={{ marginTop: 16 }}>
          <button onClick={analyzeAllPhotos} disabled={visionLoading}>
            {visionLoading ? "Analyzing Photos..." : "Analyze Uploaded Photos"}
          </button>
          {visionError && <div style={{ color: "#991b1b", marginTop: 10 }}>{visionError}</div>}
        </div>

        {!!visionResults.length && (
          <div style={{ marginTop: 16 }}>
            <h3>Vision Results</h3>
            {visionResults.map((result) => (
              <div key={result.roomId} style={{ border: "1px solid #e2e8f0", borderRadius: 12, padding: 12, marginBottom: 10 }}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <strong>{result.roomName}</strong>
                  <span>{result.confidence} confidence</span>
                </div>
                <div style={{ marginTop: 8 }}>Issues: {(result.issues || []).join(", ")}</div>
                <div style={{ marginTop: 8 }}>Suggested Scope: {(result.suggestedScope || []).map((x) => x.name).join(", ")}</div>
                <button style={{ marginTop: 10 }} onClick={() => applyVisionResult(result)}>Push Into Scope Builder</button>
              </div>
            ))}
          </div>
        )}
      </section>

      <section style={{ border: "1px solid #e2e8f0", borderRadius: 14, padding: 16 }}>
        <h2 style={{ marginTop: 0 }}>Budget Summary</h2>
        <div>Direct Cost: {currency(totals.directCost)}</div>
        <div>Rehab Total: {currency(totals.rehabTotal)}</div>
        <div>Projected Profit: {currency(totals.projectedProfit)}</div>
        <div>70% Rule MAO: {currency(totals.mao70)}</div>
        <div>Strict MAO: {currency(totals.maoStrict)}</div>
      </section>
    </main>
  );
}
