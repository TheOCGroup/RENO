
const DEFAULT_MODEL = process.env.OPENAI_VISION_MODEL || "gpt-4.1-mini";

function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
    },
    body: JSON.stringify(body),
  };
}

function safeNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function estimateQuantities(room) {
  const roomSqft = safeNumber(room?.sqft, 0);
  return {
    floorSqft: roomSqft || 150,
    wallPaintSqft: roomSqft ? Math.round(roomSqft * 2.8) : 420,
    trimLf: roomSqft ? Math.round(roomSqft / 3) : 45,
  };
}

function fallbackAnalyzeRoom(room, pricingLibrary = {}) {
  const text = `${room?.name || ""} ${room?.notes || ""} ${Array.isArray(room?.images) ? room.images.map((img) => img?.name || "").join(" ") : ""}`.toLowerCase();
  const q = estimateQuantities(room);
  const issues = [];
  const suggestedScope = [];
  let condition = room?.condition || "moderate";
  let confidence = "Low";

  if (text.includes("roof") || text.includes("leak")) {
    issues.push("Possible roof leak or roofing distress visible/noted.");
    suggestedScope.push({ name: "Roof replacement allowance", unit: "allowance", qty: 1, cost: safeNumber(pricingLibrary.roofReplacementAllowance, 7800) });
    condition = "heavy";
    confidence = "Medium";
  }
  if (text.includes("foundation") || text.includes("crack")) {
    issues.push("Possible foundation movement or wall cracking visible/noted.");
    suggestedScope.push({ name: "Foundation repair allowance", unit: "allowance", qty: 1, cost: safeNumber(pricingLibrary.foundationRepairAllowance, 8500) });
    condition = "heavy";
    confidence = "Low";
  }
  if (text.includes("kitchen") || text.includes("cabinet")) {
    issues.push("Kitchen appears outdated or distressed.");
    suggestedScope.push({ name: "Cabinet paint / hardware refresh", unit: "allowance", qty: 1, cost: safeNumber(pricingLibrary.cabinetPaintAllowance, 1800) });
  }
  if (text.includes("bath") || text.includes("shower") || text.includes("toilet")) {
    issues.push("Bathroom appears dated or distressed.");
    suggestedScope.push({ name: "Tub or shower surround", unit: "allowance", qty: 1, cost: safeNumber(pricingLibrary.tubShowerSurroundAllowance, 2200) });
  }
  if (text.includes("floor") || text.includes("carpet") || text.includes("tile")) {
    issues.push("Flooring replacement likely needed.");
    suggestedScope.push({ name: "LVP flooring", unit: "sqft", qty: q.floorSqft, cost: safeNumber(pricingLibrary.lvpPerSqft, 4.25) });
  }
  if (text.includes("paint") || text.includes("dirty") || text.includes("peel") || text.includes("stain")) {
    issues.push("Paint refresh likely needed.");
    suggestedScope.push({ name: "Interior paint", unit: "sqft", qty: q.wallPaintSqft, cost: safeNumber(pricingLibrary.interiorPaintPerSqft, 2.25) });
  }

  if (!issues.length) {
    issues.push("General deferred maintenance visible or noted.");
    suggestedScope.push({ name: "Interior paint", unit: "sqft", qty: q.wallPaintSqft, cost: safeNumber(pricingLibrary.interiorPaintPerSqft, 2.25) });
  }

  return {
    roomId: room?.id,
    roomName: room?.name || room?.type || "Room",
    roomType: room?.type || "unknown",
    condition,
    confidence,
    issues,
    estimatedQuantities: q,
    suggestedScope,
    needsVerification: ["Exact measurements", "Hidden electrical/plumbing", "Contractor confirmation for major systems"],
  };
}

async function analyzeWithOpenAI(payload) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY is not configured.");

  const rooms = Array.isArray(payload?.rooms) ? payload.rooms : [];
  const roomContent = rooms.flatMap((room) => {
    const parts = [
      {
        type: "input_text",
        text: JSON.stringify({
          roomId: room?.id,
          roomName: room?.name,
          roomType: room?.type,
          currentCondition: room?.condition,
          roomSqft: room?.sqft,
          notes: room?.notes,
        }),
      },
    ];

    const images = Array.isArray(room?.images) ? room.images : [];
    for (const image of images.slice(0, 6)) {
      if (image?.dataUrl && image?.mimeType?.startsWith("image/")) {
        parts.push({ type: "input_image", image_url: image.dataUrl });
      }
    }
    return parts;
  });

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: DEFAULT_MODEL,
      input: [
        {
          role: "system",
          content: [
            {
              type: "input_text",
              text: "You are a real-estate rehab analysis assistant. Analyze room photos and notes, then return valid JSON only with no markdown or commentary. Return an object with a results array.",
            },
          ],
        },
        {
          role: "user",
          content: [
            {
              type: "input_text",
              text: JSON.stringify({
                task: "Analyze distressed property room photos and return structured rehab scope.",
                property: payload?.property || {},
                pricingLibrary: payload?.pricingLibrary || {},
                output_format: {
                  results: [
                    {
                      roomId: "string",
                      roomName: "string",
                      roomType: "string",
                      condition: "light|moderate|heavy|severe",
                      confidence: "Low|Medium|High",
                      issues: ["string"],
                      estimatedQuantities: { floorSqft: 0, wallPaintSqft: 0, trimLf: 0 },
                      suggestedScope: [{ name: "string", unit: "allowance|sqft|lf|ea", qty: 0, cost: 0 }],
                      needsVerification: ["string"],
                    },
                  ],
                },
              }),
            },
            ...roomContent,
          ],
        },
      ],
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`OpenAI request failed: ${response.status} ${text}`);
  }

  const data = await response.json();
  const textOutput = data?.output_text;
  if (!textOutput) throw new Error("No output_text returned from OpenAI.");
  const parsed = JSON.parse(textOutput);
  if (!Array.isArray(parsed?.results)) throw new Error("Model output did not include results array.");
  return parsed;
}

export async function handler(event) {
  if (event.httpMethod === "OPTIONS") return json(200, { ok: true });
  if (event.httpMethod !== "POST") return json(405, { error: "Method not allowed" });

  try {
    const body = JSON.parse(event.body || "{}");
    const rooms = Array.isArray(body?.rooms) ? body.rooms : [];
    if (rooms.length === 0) return json(400, { error: "No rooms provided." });

    try {
      const live = await analyzeWithOpenAI(body);
      return json(200, { source: "live_ai", ...live });
    } catch (liveError) {
      const results = rooms.map((room) => fallbackAnalyzeRoom(room, body?.pricingLibrary || {}));
      return json(200, { source: "fallback", warning: liveError.message, results });
    }
  } catch (error) {
    return json(500, { error: "Failed to analyze photos.", details: error.message });
  }
}
